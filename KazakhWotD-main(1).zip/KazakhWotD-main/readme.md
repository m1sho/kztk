This is a program to give a random Kazakh word with a translation and option to export to an excel (will save previous word with translations)
required packages:
pip install translators

bugs: 

1st line gets overwritten in .txt file (wip)


credits:

m1sho, translators team, opensubtitles corpus
